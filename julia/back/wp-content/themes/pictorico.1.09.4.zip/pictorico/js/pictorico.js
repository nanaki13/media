jQuery(document).ready( function($) {

		$( '.flex-viewport-wrapper' ).flexslider( {
			animation: "slide",
			slideshow: false,
			animationLoop: true,
			controlNav: false,
			directionNav: true,
			carousel: false,
			itemMargin: 0,
		} );

});